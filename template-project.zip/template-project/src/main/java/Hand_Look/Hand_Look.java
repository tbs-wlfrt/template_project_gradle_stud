package Hand_Look;


import ev3dev.actuators.lego.motors.EV3LargeRegulatedMotor;
import ev3dev.actuators.lego.motors.EV3MediumRegulatedMotor;
import ev3dev.sensors.ev3.EV3ColorSensor;
import ev3dev.sensors.ev3.EV3TouchSensor;
import ev3dev.sensors.ev3.EV3UltrasonicSensor;
import lejos.hardware.port.MotorPort;
import lejos.hardware.port.SensorPort;
import lejos.robotics.SampleProvider;
import lejos.utility.Delay;

//import jason.asSyntax.Literal;

// The idea behind this script is that the robot "looks at your hand"
// and reacts by moving forward or backward.
// The robot
public class Hand_Look {


    static final EV3ColorSensor sensor = new EV3ColorSensor(SensorPort.S1); //drop sensor
    static boolean call_mode = false;                                        //drop sensor


    static EV3ColorSensor color = new EV3ColorSensor(SensorPort.S4);     //sort Agent Color Sensor
    static boolean call_mode2 = false;


    static EV3MediumRegulatedMotor motor1 = new EV3MediumRegulatedMotor(MotorPort.A); // Conveyor 2  Motor
    static EV3LargeRegulatedMotor motor2 = new EV3LargeRegulatedMotor(MotorPort.D); // Conveyor 2  Motor


    EV3TouchSensor touchSensor = new EV3TouchSensor(SensorPort.S2); // DropButton


    static EV3UltrasonicSensor ultrasonicSensor = new EV3UltrasonicSensor(SensorPort.S3);


    public static int check_Emergency() {


        Delay.msDelay(1);


        SampleProvider sp = ultrasonicSensor.getDistanceMode();
        int distanceValue = 0;

        float[] sample = new float[sp.sampleSize()];

        sp.fetchSample(sample, 0);
        distanceValue = (int) sample[0];

        System.out.println("Distance: " + distanceValue);

        return distanceValue;
        //if (distanceValue<100) {

    }

    public static void main(String[] args) {


        while (true) {

            int observed_distance = check_Emergency();
            // When the obstacle/hand is nearby(),
            // the robot comes closer with a fixed speed.
            if (observed_distance < 60) {
//                moveForwardNoProportional(); //Friendly Robot
//                moveForwardProportional(observed_distance); // Friendly Robot Proportional

                moveBackwardNoProportional(); //Scary Robot
//                moveBackwardProportional(observed_distance); //Scary Robot Proportional

            }
            else {
                stopMoving();
            }
        }

    }

    public static void stopMoving(){
        motor1.stop();
        motor2.stop();
    }



    public static void moveBackwardProportional(int observed_distance) {
        // Calculate proportion of distance to apply
        int proportion = Math.abs(observed_distance/10);
        // Set the speed of the motors
        motor1.setSpeed(75*proportion);
        motor2.setSpeed(75*proportion);
        // Set a delay to allow the motors to register the change.
        Delay.msDelay(1);
        // Set movement direction to backward.
        motor1.backward();
        motor2.backward();
        // Set movement direction to forward.
        Delay.msDelay(1);
    }

    public static void moveForwardProportional(int observed_distance) {
        // Calculate proportion of distance to apply
        int proportion = Math.abs(observed_distance/10);
        // Set the speed of the motors
        motor1.setSpeed(75*proportion);
        motor2.setSpeed(75*proportion);
        // Set a delay to allow the motors to register the change.
        Delay.msDelay(1);
        // Set movement direction to forward.
        motor1.forward();
        motor2.forward();
        // Set movement direction to forward.
        Delay.msDelay(1);
    }

    public static void moveForwardNoProportional() {
        // Set the speed of the motors
        motor1.setSpeed(200);
        motor2.setSpeed(200);
        // Set a delay to allow the motors to register the change.
        Delay.msDelay(1);
        // Set movement direction to forward.
        motor1.forward();
        motor2.forward();
        // Set movement direction to forward.
        Delay.msDelay(1);
    }

    public static void moveBackwardNoProportional() {
        // Set the speed of the motors
        motor1.setSpeed(200);
        motor2.setSpeed(200);
        // Set a delay to allow the motors to register the change.
        Delay.msDelay(1);
        // Set movement direction to forward.
        motor1.backward();
        motor2.backward();
        // Set movement direction to forward.
        Delay.msDelay(1);
    }

}
